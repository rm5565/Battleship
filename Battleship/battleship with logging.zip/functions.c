

#include "header.h"

#define _CRT_SECURE_NO_WARNINGS


void  welcome_screen(void) {
	char answer;
	printf("Rules of the Game\n");
	printf("This is a two player game. Player1 is you and Player2 is the computer. \nPick a pair of numbers (0-9) to guess where the enemy's ships are\n ");
	printf("Hit enter to start the game.\n");
	scanf_s("%c", &answer, 1);
}


// Return 1 or 2 for player 1 or player 2
int select_who_starts_first(void) {
	return (rand() % 2) + 1;
}



void enter_a_target(struct player_data* shooting_player, struct player_data* target_player, int *target_row, int *target_col) {
	int row, col;
	int input_ok = 0;
	
	while (input_ok == 0) {
		printf("%s, enter a target (row, col): ", shooting_player->name);
		scanf_s("%d%d", &row, &col);
		if ((row >= 0) && (row <= 9) && (col >= 0) && (col <= 9)) {

			// check if that cell was already used, ('*' or 'm')
			if ((target_player->game_board[row][col] == 'm')
				||
				(target_player->game_board[row][col] == '*')) {  // It's a miss
			// if yes, then print input error try again
				printf("That target has already been tried, shoot again.\n");
			}
			else
			input_ok = 1;
		}
		else printf("Error in input data, try again.\n");
	}
	*target_row = row;
	*target_col = col;
}



void randmonly_pick_a_target(struct player_data* shooting_player, struct player_data* target_player, int* target_row, int* target_col) {
	int row, col;
	int target_ok = 0;

	while (target_ok == 0) {
		row = rand() % 10;
		col = rand() % 10;
		if ((row >= 0) && (row <= 9) && (col >= 0) && (col <= 9)) {

			// check if that cell was already used, ('*' or 'm')
			if ((target_player->game_board[row][col] == 'm')
				||
				(target_player->game_board[row][col] == '*')) {  // It's a miss
				// if yes, then print input error try again
				// printf("That target has already been tried, shooting again.\n");
			}
			else
				target_ok = 1;
		}
		else printf("Error in input data, try again.\n");
	}
	printf("%s is shooting target at %d %d: \n", shooting_player->name, row, col);
	*target_row = row;
	*target_col = col;
}


// Return 1 if col,row is a hit, 0 if a miss
int check_shot(struct player_data* shooting_player, struct player_data* target_player, int target_row, int target_col, char* ship_type_hit) {

	//printf("checking %d %d\n", target_row, target_col);
	if (target_player->game_board[target_row][target_col] == '-') {  // It's a miss
		shooting_player->total_misses++;
		target_player->game_board[target_row][target_col] = 'm';
		//printf("miss\n");
		return 0;
	}
	else {
		//printf("hit\n");
		shooting_player->total_hits++;
		*ship_type_hit = target_player->game_board[target_row][target_col];  // return the type of ship hit so we can check if it sunk
		target_player->game_board[target_row][target_col] = '*';
	}
	return 1;
}




// Return 1 if all the ships have been sunk
int is_winner(struct player_data* target_player) {

	int i = 0;
	int j = 0;
	int ship_still_floating = 0;

	while ((i < 10) && (ship_still_floating == 0)) {
		j = 0;
		while ((j < 10) && (ship_still_floating == 0)) {
			if ((target_player->game_board[i][j] == 'c') 
								||
				(target_player->game_board[i][j] == 'b')
								||
				(target_player->game_board[i][j] == 'r')
								||
				(target_player->game_board[i][j] == 's')
								||
				(target_player->game_board[i][j] == 'd')) ship_still_floating = 1; // exit while loops as soon as we see another cell with a ship part
			j = j + 1;
		}
		i = i + 1;
	}
	if (ship_still_floating) return 0;
	return 1;
}



void update_board() {

}

void display_board(struct player_data* player, int hidden) {
	printf("%s's board:\n", player->name);
	printf("  0 1 2 3 4 5 6 7 8 9\n");
	for (int i = 0; i < 10; i++) {
		printf("%d ", i);
		for (int j = 0; j < 10; j++) {
			if (hidden == 0) {
				printf("%c ", player->game_board[i][j]);
			}
			else {
				if ((player->game_board[i][j] == 'c')
					||
					(player->game_board[i][j] == 'b')
					||
					(player->game_board[i][j] == 'r')
					||
					(player->game_board[i][j] == 's')
					||
					(player->game_board[i][j] == 'd'))
				{
					printf("%c ", '-');
				}
				else {
					printf("%c ", player->game_board[i][j]);
				}
			}
		}
		printf("\n");
	}
}





// Return 1 if the ship was sunk
int check_if_sunk_ship(struct player_data* target_player, char target_ship_type) {
	int i = 0;
	int j = 0;
	int ship_still_floating = 0;

	while ((i < 10) && (ship_still_floating == 0)) {
		while ((j < 10) && (ship_still_floating == 0)) {
			if (target_player->game_board[i][j] == target_ship_type) ship_still_floating = 1; // exit while loops as soon as we see another cell for that ship
			j = j + 1;
		}
		i = i + 1;
	}
	if (ship_still_floating == 1) return 0;
	return 1;
}



// Log file support
// --------------------------------------------------
void output_stats(FILE *log_file, struct player_data *player) {
	fprintf(log_file, "\n\nPLAYER STATS\n");
	fprintf(log_file, "%s, hits=%d, misses=%d, ratio=%f\n ", player->name, player->total_hits, player->total_misses, (float)(player->total_hits / player->total_misses));

}

// Output the current move
void output_current_move(FILE * log_file, struct player_data *player, int target_row, int target_col, int hit_or_miss, int target_sunk, int game_over) {

	fprintf(log_file, "%s move #%d: shot at %d %d ", player->name, player->total_hits + player->total_misses, target_row, target_col);
	if (hit_or_miss == 0) fprintf(log_file, "and missed.");
	else {
		fprintf(log_file, "and hit.  ");
		if (target_sunk == 1) {
			fprintf(log_file, "Ship was sunk.");
			if (game_over == 1) fprintf(log_file, "Game over");
		}
	}
	fprintf(log_file, "\n");
}



//  BELOW HERE ARE BOARD SETUP FUNCTIONS
// --------------------------------------------------

// Initialize a blank board
void initialize_game_board(struct player_data* player, char* name) {
	strncpy_s(player->name, 20, name, strlen(name));
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			player->game_board[i][j] = '-';
		}
	}
	player->total_hits = 0;
	player->total_misses = 0;
}



// Function to validate the position of the ship is ok,
// Confirm that a ship is not outside the boundaries of the board and that it
// is not on top of a ship that has already been placed.
// Return 0 if position is ok
// Return 1 if position is off the board
// Return 2 if position overlaps another ship
int verify_ship_position_ok(int ship_coordinates[5][2], int size_of_ship, struct player_data* player) {

	//for (int k = 0; k < size_of_ship; k++) printf("%d %d,  ", ship_coordinates[k][0], ship_coordinates[k][1]); printf("\n");

	// check boundaries first
	int boundaries_ok = 1;
	int index = 0;
	while ((boundaries_ok == 1) && (index < size_of_ship)) {
		if ((ship_coordinates[index][0] < 0) || (ship_coordinates[index][0] > 9) || (ship_coordinates[index][1] < 0) || (ship_coordinates[index][1] > 9))
			boundaries_ok = 0;
		index++;
	}
	if (boundaries_ok == 0) return 1;  // Off board 

	// check overlap with existing ships
	int no_overlapping = 1;
	index = 0;
	while ((no_overlapping == 1) && (index < size_of_ship)) {
		if (player->game_board[ship_coordinates[index][0]][ship_coordinates[index][1]] != '-')
			no_overlapping = 0;
		index++;
	}
	if (no_overlapping == 0) return 2;  // Overlap found

	return 0;  // All ok
}



// Get user input, validate the input, repeat input until ok, then update the gameboard for a single ship
void manually_place_one_ship(struct player_data* player, char* name_of_ship, char char_of_ship, int size_of_ship) {
	int x, y;
	int ship_coordinates[5][2];

	int input_ok = 0;
	while (input_ok != 1) {
		printf("Please enter the %d cells to place the %s across\n", size_of_ship, name_of_ship);
		for (int i = 0; i < size_of_ship; i++) {
			scanf_s("%d%d", &x, &y);
			ship_coordinates[i][0] = x;
			ship_coordinates[i][1] = y;
		}
		int input_result = verify_ship_position_ok(ship_coordinates, size_of_ship, player);
		if (input_result == 0) input_ok = 1;
		else if (input_result == 1) printf("*** Input error, ship positioned off board.  Try again.\n");
		else if (input_result == 2) printf("*** Input error, ship positioned over another ship.  Try again.\n");
	}

	// Ship position is ok, put it into the game board
	for (int i = 0; i < size_of_ship; i++) {
		player->game_board[ship_coordinates[i][0]][ship_coordinates[i][1]] = char_of_ship;
	}

	// print_game_board(player);
}



void manually_place_ships_on_board(struct player_data* player) {
	manually_place_one_ship(player, "Carrier", 'c', 5);
	manually_place_one_ship(player, "Battleship", 'b', 4);
	manually_place_one_ship(player, "Cruiser", 'r', 3);
	manually_place_one_ship(player, "Submarine", 's', 3);
	manually_place_one_ship(player, "Destroyer", 'd', 2);
}




void randomly_place_one_ship(struct player_data* player, char* name_of_ship, char char_of_ship, int size_of_ship) {
	int row, col;
	int ship_coordinates[5][2];
	int ship_is_vertical;
	int placement_ok = 0;

	while (placement_ok == 0) { // repeat until a valid placement is found
		ship_is_vertical = rand() % 2;
		col = rand() % (10 - size_of_ship);  // mod 10-size_of_ship ensures ship will fit on board
		row = rand() % (10 - size_of_ship);  // random starting place
		for (int i = 0; i < size_of_ship; i++) {
			if (ship_is_vertical == 0) {  // ship should be placed horizontally, const row, col changes
				ship_coordinates[i][0] = row;
				ship_coordinates[i][1] = col + i;
			}
			else { // ship is place vertically
				ship_coordinates[i][0] = row + i;
				ship_coordinates[i][1] = col;
			}
		}
		int placement_result = verify_ship_position_ok(ship_coordinates, size_of_ship, player);
		if (placement_result == 0) placement_ok = 1;
		// else if (placement_result == 1) printf("*** Placement error, %s positioned off board. (%d, %d) %d cells.  Trying again.\n", name_of_ship, col, row, size_of_ship);
		// else if (placement_result == 2) printf("*** Placement error, %s positioned over another ship.  Trying again.\n", name_of_ship);
	}

	// Ship position is ok, put it into the game board
	for (int i = 0; i < size_of_ship; i++) {
		player->game_board[ship_coordinates[i][0]][ship_coordinates[i][1]] = char_of_ship;
	}

	// print_game_board(player);
}



void randomly_place_ships_on_board(struct player_data* player) {

	randomly_place_one_ship(player, "Carrier", 'c', 5);
	randomly_place_one_ship(player, "Battleship", 'b', 4);
	randomly_place_one_ship(player, "Cruiser", 'r', 3);
	randomly_place_one_ship(player, "Submarine", 's', 3);
	randomly_place_one_ship(player, "Destroyer", 'd', 2);

	printf("%s's board has been generated.\n", player->name);
}

