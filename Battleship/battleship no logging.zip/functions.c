

#include "header.h"

#define _CRT_SECURE_NO_WARNINGS


void  welcome_screen(void) {
	char answer;
	printf("Rules of the Game\n");
	printf("This is a two player game. Player1 is you and Player2 is the computer. \nPick a pair of numbers (0-9) to guess where the enemy's ships are\n ");
	printf("Hit enter to start the game.\n");
	scanf_s("%c", &answer, 1);
}


// Return 1 or 2 for player 1 or player 2
int select_who_starts_first(void) {
	return (rand() % 2) + 1;
}



void enter_a_target(struct player_data* shooting_player, struct player_data* target_player, int *target_row, int *target_col) {
	int row, col;
	int input_ok = 0;
	
	while (input_ok == 0) {
		printf("%s, enter a target (row, col): ", shooting_player->name);
		scanf_s("%d%d", &row, &col);
		if ((row >= 0) && (row <= 9) && (col >= 0) && (col <= 9)) {

			// check if that cell was already used, ('*' or 'm')
			if ((target_player->game_board[row][col] == 'm')
				||
				(target_player->game_board[row][col] == '*')) {  // It's a miss
			// if yes, then print input error try again
				printf("That target has already been tried, shoot again.\n");
			}
			else
			input_ok = 1;
		}
		else printf("Error in input data, try again.\n");
	}
	*target_row = row;
	*target_col = col;
}



void randmonly_pick_a_target(struct player_data* shooting_player, struct player_data* target_player, int* target_row, int* target_col) {
	int row, col;
	int target_ok = 0;

	while (target_ok == 0) {
		row = rand() % 10;
		col = rand() % 10;
		if ((row >= 0) && (row <= 9) && (col >= 0) && (col <= 9)) {

			// check if that cell was already used, ('*' or 'm')
			if ((target_player->game_board[row][col] == 'm')
				||
				(target_player->game_board[row][col] == '*')) {  // It's a miss
				// if yes, then print input error try again
				// printf("That target has already been tried, shooting again.\n");
			}
			else
				target_ok = 1;
		}
		else printf("Error in input data, try again.\n");
	}
	printf("%s is shooting target at %d %d: \n", shooting_player->name, row, col);
	*target_row = row;
	*target_col = col;
}


int check_shot(struct player_data* shooting_player, struct player_data* target_player, int target_row, int target_col, char* ship_type_hit) {

	//printf("checking %d %d\n", target_row, target_col);
	if (target_player->game_board[target_row][target_col] == '-') {  // It's a miss
		shooting_player->total_misses++;
		target_player->game_board[target_row][target_col] = 'm';
		//printf("miss\n");
		return 0;
	}
	else {
		//printf("hit\n");
		shooting_player->total_hits++;
		*ship_type_hit = target_player->game_board[target_row][target_col];  // return the type of ship hit so we can check if it sunk
		target_player->game_board[target_row][target_col] = '*';
	}
	return 1;
}



// Return 1 if parts of any ships are still floating, 0 if all ships are sunk
int is_winner(struct player_data* target_player) {

	int i = 0;
	int j = 0;
	int ship_still_floating = 0;

	while ((i < 10) && (ship_still_floating == 0)) {
		j = 0;
		while ((j < 10) && (ship_still_floating == 0)) {
			if ((target_player->game_board[i][j] == 'c') 
								||
				(target_player->game_board[i][j] == 'b')
								||
				(target_player->game_board[i][j] == 'r')
								||
				(target_player->game_board[i][j] == 's')
								||
				(target_player->game_board[i][j] == 'd')) ship_still_floating = 1; // exit while loops as soon as we see another cell with a ship part
			j = j + 1;
		}
		i = i + 1;
	}
	return ship_still_floating;
}



void update_board() {

}

void display_board(struct player_data* player, int hidden) {
	printf("%s's board:\n", player->name);
	printf("  0 1 2 3 4 5 6 7 8 9\n");
	for (int i = 0; i < 10; i++) {
		printf("%d ", i);
		for (int j = 0; j < 10; j++) {
			if (hidden == 0) {
				printf("%c ", player->game_board[i][j]);
			}
			else {
				if ((player->game_board[i][j] == 'c')
					||
					(player->game_board[i][j] == 'b')
					||
					(player->game_board[i][j] == 'r')
					||
					(player->game_board[i][j] == 's')
					||
					(player->game_board[i][j] == 'd'))
				{
					printf("%c ", '-');
				}
				else {
					printf("%c ", player->game_board[i][j]);
				}
			}
		}
		printf("\n");
	}
}


void output_current_move() {

}


// Return 1 if parts of the ship are still floating, 0 if none and the ship is sunk
int check_if_sunk_ship(struct player_data* target_player, char target_ship_type) {
	int i = 0;
	int j = 0;
	int ship_still_floating = 0;

	while ((i < 10) && (ship_still_floating == 0)) {
		while ((j < 10) && (ship_still_floating == 0)) {
			if (target_player->game_board[i][j] == target_ship_type) ship_still_floating = 1; // exit while loops as soon as we see another cell for that ship
			j = j + 1;
		}
		i = i + 1;
	}
	return ship_still_floating;
}

void output_stats() {


}