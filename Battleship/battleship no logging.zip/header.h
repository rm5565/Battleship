#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <time.h>

#define _CRT_SECURE_NO_WARNINGS

struct player_data {
	char name[20];
	char game_board[10][10];
	int total_hits;
	int total_misses;
};


// These are implemented in functions.c
void  welcome_screen(void);
int select_who_starts_first(void);
void display_board(struct player_data* player, int hidden);
void enter_a_target(struct player_data* shooting_player, struct player_data* target_player, int* target_row, int* target_col);
void randmonly_pick_a_target(struct player_data* shooting_player, struct player_data* target_player, int* target_row, int* target_col);
int check_shot(struct player_data* shooting_player, struct player_data* target_player, int target_row, int target_col, char* ship_type_hit);
int check_if_sunk_ship(struct player_data* target_player, char target_ship_type);


// These are implemented in boardsetup.c
void initialize_game_board(struct player_data* player, char* name);
void manually_place_ships_on_board(struct player_data* player);
void randomly_place_ships_on_board(struct player_data* player);

